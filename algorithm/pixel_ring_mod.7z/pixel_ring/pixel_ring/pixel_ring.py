

class PixelRing(object):
    def __init__(self):
        pass

    def show(self, data):
        pass

    def set_color(self, rgb=None, r=0, g=0, b=0):
        pass

    def wakeup(self, angle=None):
        pass

    def listen(self):
        pass

    def think(self):
        pass

    def speak(self):
        pass

    def off(self):
        pass
    
    def open1(self):
        pass
    
    def open2(self):
        pass
    
    def open3(self):
        pass
    
    def open4(self):
        pass
